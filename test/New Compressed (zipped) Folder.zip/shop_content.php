<?php
// Generate or fetch shop content dynamically
echo "<p>This is the shop content.</p>";
?>
